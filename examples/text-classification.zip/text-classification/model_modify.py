import os
import sys
import argparse
import torch
from transformers import (
    BertForSequenceClassification,
    BertTokenizer,
    Trainer,
    TrainingArguments,
    DataCollatorWithPadding,
    BertConfig
)
from datasets import load_dataset
from torch.utils.data import DataLoader
import evaluate
import numpy as np

# 添加当前路径以导入近似模块
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from approximation_plain import replace_bert_modules


def compute_metrics(eval_pred, task_name):
    """修正metric计算逻辑，适配所有GLUE任务"""
    metric = evaluate.load("glue", task_name)
    predictions, labels = eval_pred
    if task_name == "stsb":
        predictions = predictions[:, 0]
    elif task_name in ["cola", "sst2", "mrpc", "qnli", "rte"]:
        predictions = np.argmax(predictions, axis=1)
    else:
        raise ValueError(f"Unsupported task for metrics: {task_name}")
    result = metric.compute(predictions=predictions, references=labels)
    if task_name == "cola":
        return {"matthews_correlation": result["matthews_correlation"]}
    elif task_name == "mrpc":
        return {"accuracy": result["accuracy"], "f1": result["f1"]}
    else:
        return {"accuracy": result["accuracy"]}


def evaluate_model(model, val_dataset, tokenizer, task, batch_size, device):
    """使用 DataLoader 安全评估模型，自动 padding"""
    data_collator = DataCollatorWithPadding(tokenizer=tokenizer, padding=True)
    dataloader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        collate_fn=data_collator,
        shuffle=False
    )

    model.eval()
    all_preds = []
    all_labels = []

    with torch.no_grad():
        for batch in dataloader:
            labels = batch.pop("labels").to(device)
            batch = {k: v.to(device) for k, v in batch.items()}
            outputs = model(**batch)
            logits = outputs.logits

            if task == "stsb":
                preds = logits.squeeze(-1)
            else:
                preds = logits.argmax(dim=-1)

            all_preds.append(preds.cpu())
            all_labels.append(labels.cpu())

    temp_preds = torch.cat(all_preds).numpy()
    unique, counts = np.unique(temp_preds, return_counts=True)
    print(f"DEBUG: 预测分布: 类别 {unique} -> 数量 {counts}")

    all_preds = torch.cat(all_preds).numpy()
    all_labels = torch.cat(all_labels).numpy()

    metric = evaluate.load("glue", task)
    if task == "stsb":
        result = metric.compute(predictions=all_preds, references=all_labels)["pearson"]
    elif task == "mrpc":
        acc = metric.compute(predictions=all_preds, references=all_labels)["accuracy"]
        f1 = metric.compute(predictions=all_preds, references=all_labels)["f1"]
        result = {"accuracy": acc, "f1": f1}
    elif task == "cola":
        result = metric.compute(predictions=all_preds, references=all_labels)["matthews_correlation"]
    else:
        result = metric.compute(predictions=all_preds, references=all_labels)["accuracy"]

    return result, all_preds, all_labels


class CustomTrainer(Trainer):
    def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
        labels = inputs.pop("labels")
        outputs = model(**inputs, labels=labels)
        loss = outputs.loss
        return (loss, outputs) if return_outputs else loss


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task", type=str, default="sst2", 
                        choices=["sst2", "mrpc", "qnli", "rte", "cola", "stsb"])
    parser.add_argument("--output_dir", type=str, default="./checkpoints")
    parser.add_argument("--num_train_epochs", type=int, default=1)
    parser.add_argument("--approx_num_train_epochs", type=int, default=1)
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--learning_rate", type=float, default=2e-5)
    parser.add_argument("--approx_learning_rate", type=float, default=2e-5)
    parser.add_argument("--max_seq_length", type=int, default=128)
    parser.add_argument("--skip_finetune", action="store_true", 
                        help="Skip fine-tuning even if model missing")
    parser.add_argument("--gradient_accumulation_steps", type=int, default=1,
                        help="梯度累积，适配小显存GPU")
    args = parser.parse_args()

    task = args.task.lower()
    orig_output_dir = os.path.join(args.output_dir, f"test_var_{task}")
    approx_output_dir = os.path.join(args.output_dir, f"test_var_{task}_approx")

    orig_model_path = os.path.join(orig_output_dir, "pytorch_model.bin")
    approx_model_path = os.path.join(approx_output_dir, "pytorch_model.bin")
    need_orig_finetune = not os.path.exists(orig_model_path)
    need_approx_finetune = not os.path.exists(approx_model_path)

    os.makedirs(orig_output_dir, exist_ok=True)
    os.makedirs(approx_output_dir, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"🚀 Running SHAFT-style evaluation on GLUE/{task.upper()} (Device: {device})")

    # ==============================
    # Step 0: 数据预处理（动态字段适配）
    # ==============================
    tokenizer = BertTokenizer.from_pretrained(
        "bert-base-uncased", 
        clean_up_tokenization_spaces=True,
        padding_side="right"
    )

    # GLUE 字段映射表
    TASK_TO_KEYS = {
        "cola": ("sentence", None),
        "sst2": ("sentence", None),
        "mrpc": ("sentence1", "sentence2"),
        "qqp": ("question1", "question2"),
        "stsb": ("sentence1", "sentence2"),
        "mnli": ("premise", "hypothesis"),
        "qnli": ("question", "sentence"),   # ← 关键修复
        "rte": ("sentence1", "sentence2"),
    }

    if task not in TASK_TO_KEYS:
        raise ValueError(f"Task '{task}' not supported. Available: {list(TASK_TO_KEYS.keys())}")
    text_column_1, text_column_2 = TASK_TO_KEYS[task]

    def preprocess_function(examples):
        if text_column_2 is None:
            return tokenizer(
                examples[text_column_1],
                truncation=True,
                max_length=args.max_seq_length,
                padding=False,
                return_token_type_ids=False,
            )
        else:
            return tokenizer(
                examples[text_column_1],
                examples[text_column_2],
                truncation=True,
                max_length=args.max_seq_length,
                padding=False,
                return_token_type_ids=True,
            )

    train_dataset = load_dataset("glue", task, split="train")
    val_dataset = load_dataset("glue", task, split="validation")

    train_dataset = train_dataset.map(
        preprocess_function,
        batched=True,
        remove_columns=[col for col in train_dataset.column_names if col not in ["label", "input_ids", "attention_mask"]]
    )
    val_dataset = val_dataset.map(
        preprocess_function,
        batched=True,
        remove_columns=[col for col in val_dataset.column_names if col not in ["label", "input_ids", "attention_mask"]]
    )

    # 重命名 label → labels
    if "label" in train_dataset.column_names:
        train_dataset = train_dataset.rename_column("label", "labels")
        val_dataset = val_dataset.rename_column("label", "labels")

    train_dataset.set_format(type="torch", columns=["input_ids", "attention_mask", "labels"])
    val_dataset.set_format(type="torch", columns=["input_ids", "attention_mask", "labels"])

    data_collator = DataCollatorWithPadding(tokenizer=tokenizer)

    # 任务配置
    num_labels = 1 if task == "stsb" else 2
    TASK_TO_METRIC = {
        "sst2": "eval_accuracy",
        "qnli": "eval_accuracy",
        "rte": "eval_accuracy",
        "mrpc": "eval_f1",
        "cola": "eval_matthews_correlation",
        "stsb": "eval_pearson",
    }
    metric_for_best_model = TASK_TO_METRIC[task]

    # ==============================
    # Step 1: 原生模型训练/加载
    # ==============================
    model_orig = None
    if need_orig_finetune and not args.skip_finetune:
        print(f"🔍 Original model not found. Starting fine-tuning...")
        model_orig = BertForSequenceClassification.from_pretrained(
            "bert-base-uncased",
            num_labels=num_labels,
            ignore_mismatched_sizes=True
        )

        training_args = TrainingArguments(
            output_dir=orig_output_dir,
            eval_strategy="epoch",
            save_strategy="epoch",
            per_device_train_batch_size=args.batch_size,
            per_device_eval_batch_size=args.batch_size,
            learning_rate=args.learning_rate,
            num_train_epochs=args.num_train_epochs,
            logging_steps=100,
            save_total_limit=1,
            load_best_model_at_end=True,
            metric_for_best_model=metric_for_best_model,
            greater_is_better=True,
            report_to="none",
            save_safetensors=False,
            gradient_accumulation_steps=args.gradient_accumulation_steps,
            fp16=torch.cuda.is_available(),
        )

        trainer = CustomTrainer(
            model=model_orig,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=val_dataset,
            processing_class=tokenizer,
            data_collator=data_collator,
            compute_metrics=lambda p: compute_metrics(p, task),
        )

        trainer.train()
        trainer.save_model(orig_output_dir)
        print(f"✅ Original fine-tuned model saved to {orig_output_dir}")
    elif need_orig_finetune and args.skip_finetune:
        print(f"⚠️ Original model missing but skip_finetune is set. Will skip original model eval.")
    else:
        print(f"✅ Found existing original model. Skipping fine-tuning.")
        model_orig = BertForSequenceClassification.from_pretrained(
            orig_output_dir,
            num_labels=num_labels,
            ignore_mismatched_sizes=True
        )

    # ==============================
    # Step 2: 近似模型训练/加载
    # ==============================
    model_approx = None
    if need_approx_finetune and not args.skip_finetune:
        print(f"🔍 Approximate model not found. Building and fine-tuning...")
        
        # 1. 加载原始模型（作为权重源）
        print("   Loading original weights source...")
        model_source = BertForSequenceClassification.from_pretrained(
            orig_output_dir,
            num_labels=num_labels,
            ignore_mismatched_sizes=True
        )
        
        # 2. 构建目标近似模型结构
        # 这里我们也加载一遍，主要是为了获取config和整体结构
        model_approx = BertForSequenceClassification.from_pretrained(
            orig_output_dir,
            num_labels=num_labels,
            ignore_mismatched_sizes=True
        )

        # 3. 替换近似模块（此时 model_approx 的核心层变成了随机初始化）
        print("   Replacing BERT modules with approximation operators...")
        model_approx.bert = replace_bert_modules(model_approx.bert)

        # 4. 【关键修复】将原始模型的权重迁移到近似模型
        # 由于 CustomBertLayer 结构与 原生 BertLayer 在参数命名上完全一致（dense, query, key, value），
        # 我们可以直接加载 state_dict。strict=False 会忽略掉近似算子里的 coeffs (它们不需要加载，是算出的)
        print("   🔥🔥 Transferring weights from Original to Approximate model...")
        model_approx.load_state_dict(model_source.state_dict(), strict=False)

        # 释放 source 模型节省显存
        del model_source
        torch.cuda.empty_cache()

        approx_training_args = TrainingArguments(
            output_dir=approx_output_dir,
            eval_strategy="epoch",
            save_strategy="epoch",
            per_device_train_batch_size=args.batch_size,
            per_device_eval_batch_size=args.batch_size,
            learning_rate=args.approx_learning_rate,
            num_train_epochs=args.approx_num_train_epochs,
            logging_steps=100,
            save_total_limit=1,
            load_best_model_at_end=True,
            metric_for_best_model=metric_for_best_model,
            greater_is_better=True,
            report_to="none",
            save_safetensors=False,
            gradient_accumulation_steps=args.gradient_accumulation_steps,
            fp16=torch.cuda.is_available(),
        )

        approx_trainer = CustomTrainer(
            model=model_approx,
            args=approx_training_args,
            train_dataset=train_dataset,
            eval_dataset=val_dataset,
            processing_class=tokenizer,
            data_collator=data_collator,
            compute_metrics=lambda p: compute_metrics(p, task),
        )

        approx_trainer.train()
        approx_trainer.save_model(approx_output_dir)
        print(f"✅ Approximate fine-tuned model saved to {approx_output_dir}")
    elif need_approx_finetune and args.skip_finetune:
        raise FileNotFoundError(f"--skip_finetune is set, but approximate model not found at {approx_model_path}")
    else:
        # =================================================================
        # 【核心修复】正确的加载已训练近似模型的方法：
        # 1. 仅加载 Config
        # 2. 初始化标准模型（随机权重）
        # 3. 替换结构（加入 exp_plus_one 等层）
        # 4. 加载微调好的 Checkpoint 权重
        # =================================================================
        print(f"✅ Found existing approximate model. Loading with STRUCTURE FIX...")
        
        # 1. Config
        config = BertConfig.from_pretrained(approx_output_dir, num_labels=num_labels)
        
        # 2. Init random model
        model_approx = BertForSequenceClassification(config)
        
        # 3. Replace structure
        model_approx.bert = replace_bert_modules(model_approx.bert)
        
        # 4. Load weights
        approx_checkpoint_path = os.path.join(approx_output_dir, "pytorch_model.bin")
        if os.path.exists(approx_checkpoint_path):
            state_dict = torch.load(approx_checkpoint_path, map_location="cpu")
            missing, unexpected = model_approx.load_state_dict(state_dict, strict=False)
            print(f"   Weights loaded manually. Missing keys: {len(missing)}, Unexpected keys: {len(unexpected)}")
        else:
            raise FileNotFoundError(f"Checkpoint binary not found at {approx_checkpoint_path}")

    # ==============================
    # Step 3: 模型评估
    # ==============================
    orig_acc = 0.0
    
    # 判空检查：防止 model_orig 为 None 时报错
    if model_orig is not None:
        print("📊 Evaluating original fine-tuned BERT...")
        model_orig.to(device)
        orig_result, _, _ = evaluate_model(
            model_orig, val_dataset, tokenizer, task, args.batch_size, device
        )

        if isinstance(orig_result, dict):
            # 取出第一个主要的指标
            orig_acc = list(orig_result.values())[0]
            # 尝试获取 F1，没有则忽略
            orig_f1 = orig_result.get("f1", "N/A")
            print(f"✅ Original BERT - Main Metric: {orig_acc:.4f}, F1: {orig_f1}")
        else:
            orig_acc = orig_result
            print(f"✅ Original BERT - Main Metric: {orig_acc:.4f}")
    else:
        print("⚠️ Original model not loaded (skipped).")

    if model_approx is not None:
        print("📊 Evaluating fine-tuned approximate BERT...")
        model_approx.to(device)
        approx_result, _, _ = evaluate_model(
            model_approx, val_dataset, tokenizer, task, args.batch_size, device
        )

        if isinstance(approx_result, dict):
            approx_acc = list(approx_result.values())[0]
            approx_f1 = approx_result.get("f1", "N/A")
            print(f"✅ Approx BERT - Main Metric: {approx_acc:.4f}, F1: {approx_f1}")
        else:
            approx_acc = approx_result
            print(f"✅ Approx BERT - Main Metric: {approx_acc:.4f}")

        # 打印对比报告
        if model_orig is not None:
            drop = orig_acc - approx_acc
            print("\n" + "=" * 60)
            print(f"🎯 SHAFT-Style Evaluation Report: GLUE/{task.upper()}")
            print(f"   Original BERT:    {orig_acc:.4f}")
            print(f"   Approximate BERT: {approx_acc:.4f} (after {args.approx_num_train_epochs} epochs fine-tuning)")
            print(f"   Performance Drop: {drop:.4f} ({drop * 100:.2f}%)")
            print("=" * 60)

if __name__ == "__main__":
    main()